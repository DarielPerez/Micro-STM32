/* USER CODE BEGIN Header */
/**
 *
 * Dariel Perez
 * 2020-10347
 * Generador de ondas
 * Microcontroladores
 * C1-2024
 *
 ******************************************************************************
 * @file           : main.c
 * @brief          : Main program body
 ******************************************************************************
 * @attention
 *
 * Copyright (c) 2024 STMicroelectronics.
 * All rights reserved.
 *
 * This software is licensed under terms that can be found in the LICENSE file
 * in the root directory of this software component.
 * If no LICENSE file comes with this software, it is provided AS-IS.
 *
 ******************************************************************************
 */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "math.h"
#include"string.h"
#include"stdio.h"
#include "i2c-lcd.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
DAC_HandleTypeDef hdac;
DMA_HandleTypeDef hdma_dac_ch1;

I2C_HandleTypeDef hi2c1;

TIM_HandleTypeDef htim2;
TIM_HandleTypeDef htim15;

UART_HandleTypeDef huart2;

/* USER CODE BEGIN PV */
uint32_t ondaSeno [100];
uint32_t ondaTri [100];
uint32_t ondaCuad [100];
uint32_t ondaCier [100];

#define PI 3.1415926
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_DMA_Init(void);
static void MX_USART2_UART_Init(void);
static void MX_I2C1_Init(void);
static void MX_TIM2_Init(void);
static void MX_DAC_Init(void);
static void MX_TIM15_Init(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

uint32_t contador_0 = 0;
int16_t cont = 0;
int16_t pos = 0;


int prueba = 0;
int menu, submenu, submenu2, submenu3, submenu4 = 0;
float fq1 = 0.02f;
float amp1 = 0.01f;
int fsen, ftri, fcuad, fcier = 0;
int cuenta = 0;


void HAL_TIM_IC_CaptureCallback(TIM_HandleTypeDef *htim)
{
	contador_0 = __HAL_TIM_GET_COUNTER(htim);
	cont = (int16_t)contador_0;
	pos = cont/6;
}

void ondaSen()
{
	for (int x =0; x < 100; x++) {
		ondaSeno[x] = ((sin (x * 2 * PI/100)+1) * (amp1 * 4096/2));
	}
}

void ondacuadrada ()
{
	for (int a = 0;  a< 100; a++) {
		if (a < 50)
			ondaCuad[a] = 0;
		else
			ondaCuad[a] =  (amp1 * 4096);
	}
}
void ondaCierr()
{
	for (int y =0; y < 100; y++) {
		ondaCier[y] = (y * (amp1 * 4096 / 100));
	}
}

void ondatriangular()
{
    for (int z = 0; z < 100; z++)
    {
        if (z < 50)
        	ondaTri[z] = ((z * (amp1 * 4096 / 50)));
        else
        	ondaTri[z] = (((100 - z) * (amp1 * 4096 / 50)));
    }
}

void enviar(uint32_t valor){
	char buffer [20];
	sprintf(buffer,"%lu\r\n",valor);
	HAL_UART_Transmit(&huart2, (uint32_t*)buffer, strlen(buffer), HAL_MAX_DELAY);
}


/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_DMA_Init();
  MX_USART2_UART_Init();
  MX_I2C1_Init();
  MX_TIM2_Init();
  MX_DAC_Init();
  MX_TIM15_Init();
  /* USER CODE BEGIN 2 */
	HAL_TIM_Encoder_Start_IT(&htim2, TIM_CHANNEL_ALL);
	lcd_init();
	HAL_TIM_Base_Start(&htim15);

	HAL_DAC_Start_DMA(&hdac, DAC_CHANNEL_1,ondaSeno, 100, DAC_ALIGN_12B_R);
	HAL_DAC_Start_DMA(&hdac, DAC_CHANNEL_1,ondaTri, 100, DAC_ALIGN_12B_R);
	HAL_DAC_Start_DMA(&hdac, DAC_CHANNEL_1,ondaCuad, 100, DAC_ALIGN_12B_R);
	HAL_DAC_Start_DMA(&hdac, DAC_CHANNEL_1,ondaCier, 100, DAC_ALIGN_12B_R);
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
	while (1)
	{
		ondaSen();
		ondaCierr();
		ondacuadrada();
		ondatriangular();
    /* USER CODE END WHILE */
		if (cuenta == 1)
		{
		for (int i = 0; i < 100; i++)
		{

		DAC->DHR12R1 = ondaSeno[i];
		HAL_Delay(fq1);
		enviar(ondaSeno[i]);
		}
		}

		else if (cuenta ==  4)
		{
		for (int i = 0; i < 100; i++)
		{

		DAC->DHR12R1 = ondaCier[i];
		HAL_Delay(fq1);
		enviar(ondaCier[i]);

		}
		}
		else if (cuenta ==  3)
		{
		for (int i = 0; i < 100; i++)
		{

		DAC->DHR12R1 = ondaCuad[i];
		HAL_Delay(fq1);
		enviar(ondaCuad[i]);

		}
		}
		else if (cuenta ==  2)
		{
		for (int i = 0; i < 100; i++)
		{

		DAC->DHR12R1 = ondaTri[i];
		HAL_Delay(fq1);
		enviar(ondaTri[i]);

		}
		}
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		   //Switch 1
		   		switch (menu) { //este switch maneja el menu completo
		   		case 0:
		   			//aqui se captura el movimiento del encoder y se iguala a una variable la cual representara en que lugar esta el cursor
		   			if (pos <= 0) {
		   				prueba = 1;
		   			} else if (pos == 1) {
		   				prueba = 2;
		   			} else if (pos == 2) {
		   				prueba = 3;
		   			} else if (pos >= 3) {
		   				prueba = 4;
		   			} else {
		   				prueba = 0;
		   			}

		   			//esto seria el menu principal
		   			//switch 1.1
		   			switch (prueba) {
		   			case 1:
		   				lcd_send_cmd(0x80|0x00);
		   				lcd_send_string(">");
		   				lcd_send_cmd(0x80|0x01);
		   				lcd_send_string("SENOIDAL");
		   				lcd_send_cmd(0x80|0x41);
		   				lcd_send_string("TRIANGULAR");
		   				lcd_send_cmd(0x80|0x15);
		   				lcd_send_string("CUADRADA");
		   				lcd_send_cmd(0x80|0x55);
		   				lcd_send_string("CIERRA");
		   				lcd_clear();
		   				if(HAL_GPIO_ReadPin(btn_encoder_GPIO_Port, btn_encoder_Pin)==0){
		   					HAL_Delay(5);
		   					while (HAL_GPIO_ReadPin(btn_encoder_GPIO_Port, btn_encoder_Pin)==0);
		   					HAL_Delay(5);
		   					menu = 1;
		   					pos = 0;
		   					fsen = 1;
		   					ftri = 0;
		   					fcuad = 0;
		   					fcier = 0;
		   				}
		   				break;
		   			case 2:
		   				lcd_send_cmd(0x80|0x40);
		   				lcd_send_string(">");
		   				lcd_send_cmd(0x80|0x01);
		   				lcd_send_string("SENOIDAL");
		   				lcd_send_cmd(0x80|0x41);
		   				lcd_send_string("TRIANGULAR");
		   				lcd_send_cmd(0x80|0x15);
		   				lcd_send_string("CUADRADA");
		   				lcd_send_cmd(0x80|0x55);
		   				lcd_send_string("CIERRA");
		   				lcd_clear();
		   				if(HAL_GPIO_ReadPin(btn_encoder_GPIO_Port, btn_encoder_Pin)==0){
		   					HAL_Delay(5);
		   					while (HAL_GPIO_ReadPin(btn_encoder_GPIO_Port, btn_encoder_Pin)==0);
		   					HAL_Delay(5);
		   					menu = 2;
		   					pos = 0;
		   					fsen = 0;
		   					ftri = 1;
		   					fcuad = 0;
		   					fcier = 0;
		   				}
		   				break;
		   			case 3:
		   				lcd_send_cmd(0x80|0x14);
		   				lcd_send_string(">");
		   				lcd_send_cmd(0x80|0x01);
		   				lcd_send_string("SENOIDAL");
		   				lcd_send_cmd(0x80|0x41);
		   				lcd_send_string("TRIANGULAR");
		   				lcd_send_cmd(0x80|0x15);
		   				lcd_send_string("CUADRADA");
		   				lcd_send_cmd(0x80|0x55);
		   				lcd_send_string("CIERRA");
		   				lcd_clear();
		   				if(HAL_GPIO_ReadPin(btn_encoder_GPIO_Port, btn_encoder_Pin)==0){
		   					HAL_Delay(5);
		   					while (HAL_GPIO_ReadPin(btn_encoder_GPIO_Port, btn_encoder_Pin)==0);
		   					HAL_Delay(5);
		   					menu = 3;
		   					pos = 0;
		   					fsen = 0;
		   					ftri = 0;
		   					fcuad = 1;
		   					fcier = 0;
		   				}
		   				break;
		   			case 4:
		   				lcd_send_cmd(0x80|0x54);
		   				lcd_send_string(">");
		   				lcd_send_cmd(0x80|0x01);
		   				lcd_send_string("SENOIDAL");
		   				lcd_send_cmd(0x80|0x41);
		   				lcd_send_string("TRIANGULAR");
		   				lcd_send_cmd(0x80|0x15);
		   				lcd_send_string("CUADRADA");
		   				lcd_send_cmd(0x80|0x55);
		   				lcd_send_string("CIERRA");
		   				lcd_clear();
		   				if(HAL_GPIO_ReadPin(btn_encoder_GPIO_Port, btn_encoder_Pin)==0){
		   					HAL_Delay(5);
		   					while (HAL_GPIO_ReadPin(btn_encoder_GPIO_Port, btn_encoder_Pin)==0);
		   					HAL_Delay(5);
		   					menu = 4;
		   					pos = 0;
		   					fsen = 0;
		   					ftri = 0;
		   					fcuad = 0;
		   					fcier = 1;
		   				}
		   				break;
		   			default:
		   				lcd_clear();
		   				break;
		   			}
		   			break;//fin switch 1.1

		   			case 1://aqui inicia el sub menu de senoidal
		   				if (pos <= 0) {
		   					submenu = 1;
		   				} else if (pos == 1) {
		   					submenu = 2;
		   				} else if (pos >= 2) {
		   					submenu = 3;
		   				}
		   				//aqui configuramos las opciones de para la onda senoidal
		   				//switch 1.2
		   				switch (submenu) {
		   				case 1://para cambiar la frecuencia
		   					lcd_send_cmd(0x80|0x00);
		   					lcd_send_string(">");
		   					lcd_send_cmd(0x80|0x01);
		   					lcd_send_string("FRECUENCIA");
		   					lcd_send_cmd(0x80|0x41);
		   					lcd_send_string("AMPLITUD");
		   					lcd_send_cmd(0x80|0x15);
		   					lcd_send_string("ATRAS");
		   					lcd_clear();
		   					if(HAL_GPIO_ReadPin(btn_encoder_GPIO_Port, btn_encoder_Pin)==0){
		   						HAL_Delay(5);
		   						while (HAL_GPIO_ReadPin(btn_encoder_GPIO_Port, btn_encoder_Pin)==0);
		   						HAL_Delay(5);
		   						menu = 5;
		   						pos = 0;
		   					}
		   					break;
		   				case 2://para cambiar la amplitud
		   					lcd_send_cmd(0x80|0x40);
		   					lcd_send_string(">");
		   					lcd_send_cmd(0x80|0x01);
		   					lcd_send_string("FRECUENCIA");
		   					lcd_send_cmd(0x80|0x41);
		   					lcd_send_string("AMPLITUD");
		   					lcd_send_cmd(0x80|0x15);
		   					lcd_send_string("ATRAS");
		   					lcd_clear();
		   					if(HAL_GPIO_ReadPin(btn_encoder_GPIO_Port, btn_encoder_Pin)==0){
		   						HAL_Delay(5);
		   						while (HAL_GPIO_ReadPin(btn_encoder_GPIO_Port, btn_encoder_Pin)==0);
		   						HAL_Delay(5);
		   						menu = 6;
		   						pos = 0;
		   					}
		   					break;
		   				case 3://para volver al menu principal
		   					lcd_send_cmd(0x80|0x14);
		   					lcd_send_string(">");
		   					lcd_send_cmd(0x80|0x01);
		   					lcd_send_string("FRECUENCIA");
		   					lcd_send_cmd(0x80|0x41);
		   					lcd_send_string("AMPLITUD");
		   					lcd_send_cmd(0x80|0x15);
		   					lcd_send_string("ATRAS");
		   					lcd_clear();
		   					if(HAL_GPIO_ReadPin(btn_encoder_GPIO_Port, btn_encoder_Pin)==0){
		   						HAL_Delay(5);
		   						while (HAL_GPIO_ReadPin(btn_encoder_GPIO_Port, btn_encoder_Pin)==0);
		   						HAL_Delay(5);
		   						menu = 0;
		   						pos = 0;

		   					}
		   					break;
		   				default:
		   					menu = 0;
		   					break;

		   				}
		   				//fin switch 1.2
		   				case 2://aqui inicia el sub menu de triangular
		   					if (pos <= 0) {
		   						submenu2 = 1;
		   					} else if (pos == 1) {
		   						submenu2 = 2;
		   					} else if (pos >= 2) {
		   						submenu2 = 3;
		   					}
		   					//aqui configuramos las opciones de para la onda triangular
		   					//switch 1.3
		   					switch (submenu2) {
		   					case 1://para cambiar la frecuencia
		   						lcd_send_cmd(0x80|0x00);
		   						lcd_send_string(">");
		   						lcd_send_cmd(0x80|0x01);
		   						lcd_send_string("FRECUENCIA");
		   						lcd_send_cmd(0x80|0x41);
		   						lcd_send_string("AMPLITUD");
		   						lcd_send_cmd(0x80|0x15);
		   						lcd_send_string("ATRAS");

		   						lcd_clear();
		   						if(HAL_GPIO_ReadPin(btn_encoder_GPIO_Port, btn_encoder_Pin)==0){
		   							HAL_Delay(5);
		   							while (HAL_GPIO_ReadPin(btn_encoder_GPIO_Port, btn_encoder_Pin)==0);
		   							HAL_Delay(5);
		   							menu = 7;
		   							pos = 0;
		   						}
		   						break;
		   					case 2://para cambiar la amplitud
		   						lcd_send_cmd(0x80|0x40);
		   						lcd_send_string(">");
		   						lcd_send_cmd(0x80|0x01);
		   						lcd_send_string("FRECUENCIA");
		   						lcd_send_cmd(0x80|0x41);
		   						lcd_send_string("AMPLITUD");
		   						lcd_send_cmd(0x80|0x15);
		   						lcd_send_string("ATRAS");
		   						lcd_clear();
		   						if(HAL_GPIO_ReadPin(btn_encoder_GPIO_Port, btn_encoder_Pin)==0){
		   							HAL_Delay(5);
		   							while (HAL_GPIO_ReadPin(btn_encoder_GPIO_Port, btn_encoder_Pin)==0);
		   							HAL_Delay(5);
		   							menu = 8;
		   							pos = 0;
		   						}
		   						break;
		   					case 3://para volver al menu principal
		   						lcd_send_cmd(0x80|0x14);
		   						lcd_send_string(">");
		   						lcd_send_cmd(0x80|0x01);
		   						lcd_send_string("FRECUENCIA");
		   						lcd_send_cmd(0x80|0x41);
		   						lcd_send_string("AMPLITUD");
		   						lcd_send_cmd(0x80|0x15);
		   						lcd_send_string("ATRAS");
		   						lcd_clear();
		   						if(HAL_GPIO_ReadPin(btn_encoder_GPIO_Port, btn_encoder_Pin)==0){
		   							HAL_Delay(5);
		   							while (HAL_GPIO_ReadPin(btn_encoder_GPIO_Port, btn_encoder_Pin)==0);
		   							HAL_Delay(5);
		   							menu = 0;
		   							pos = 0;
		   						}
		   						break;
		   					default:
		   						menu = 0;
		   						break;//fin switch 1.3
		   					}
		   					case 3://aqui inicia el sub menu de cuadrada
		   						if (pos <= 0) {
		   							submenu3 = 1;
		   						} else if (pos == 1) {
		   							submenu3 = 2;
		   						} else if (pos >= 2) {
		   							submenu3 = 3;
		   						}
		   						//aqui configuramos las opciones de para la onda cuadrada
		   						//switch 1.4
		   						switch (submenu3) {
		   						case 1://para cambiar la frecuencia

		   							lcd_send_cmd(0x80|0x00);
		   							lcd_send_string(">");
		   							lcd_send_cmd(0x80|0x01);
		   							lcd_send_string("FRECUENCIA");
		   							lcd_send_cmd(0x80|0x41);
		   							lcd_send_string("AMPLITUD");
		   							lcd_send_cmd(0x80|0x15);
		   							lcd_send_string("ATRAS");

		   							lcd_clear();
		   							if(HAL_GPIO_ReadPin(btn_encoder_GPIO_Port, btn_encoder_Pin)==0){
		   								HAL_Delay(5);
		   								while (HAL_GPIO_ReadPin(btn_encoder_GPIO_Port, btn_encoder_Pin)==0);
		   								HAL_Delay(5);
		   								menu = 9;
		   								pos = 0;
		   							}
		   							break;
		   						case 2://para cambiar la amplitud
		   							lcd_send_cmd(0x80|0x40);
		   							lcd_send_string(">");
		   							lcd_send_cmd(0x80|0x01);
		   							lcd_send_string("FRECUENCIA");
		   							lcd_send_cmd(0x80|0x41);
		   							lcd_send_string("AMPLITUD");
		   							lcd_send_cmd(0x80|0x15);
		   							lcd_send_string("ATRAS");
		   							lcd_clear();
		   							if(HAL_GPIO_ReadPin(btn_encoder_GPIO_Port, btn_encoder_Pin)==0){
		   								HAL_Delay(5);
		   								while (HAL_GPIO_ReadPin(btn_encoder_GPIO_Port, btn_encoder_Pin)==0);
		   								HAL_Delay(5);
		   								menu = 10;
		   								pos = 0;
		   							}
		   							break;
		   						case 3://para volver al menu principal
		   							lcd_send_cmd(0x80|0x14);
		   							lcd_send_string(">");
		   							lcd_send_cmd(0x80|0x01);
		   							lcd_send_string("FRECUENCIA");
		   							lcd_send_cmd(0x80|0x41);
		   							lcd_send_string("AMPLITUD");
		   							lcd_send_cmd(0x80|0x15);
		   							lcd_send_string("ATRAS");
		   							lcd_clear();
		   							if(HAL_GPIO_ReadPin(btn_encoder_GPIO_Port, btn_encoder_Pin)==0){
		   								HAL_Delay(5);
		   								while (HAL_GPIO_ReadPin(btn_encoder_GPIO_Port, btn_encoder_Pin)==0);
		   								HAL_Delay(5);
		   								menu = 0;
		   								pos = 0;
		   							}
		   							break;
		   						default:
		   							menu = 0;
		   							break;//fin switch 1.4
		   						}
		   						case 4: //aqui inicia el sub menu de pico de cierra
		   							if (pos <= 0) {
		   								submenu4 = 1;
		   							} else if (pos == 1) {
		   								submenu4 = 2;
		   							} else if (pos >= 2) {
		   								submenu4 = 3;
		   							}
		   							//aqui configuramos las opciones de para la onda cierra
		   							//swuitch 1.6
		   							switch (submenu4) {
		   							case 1://para cambiar la frecuencia

		   								lcd_send_cmd(0x80|0x00);
		   								lcd_send_string(">");
		   								lcd_send_cmd(0x80|0x01);
		   								lcd_send_string("FRECUENCIA");
		   								lcd_send_cmd(0x80|0x41);
		   								lcd_send_string("AMPLITUD");
		   								lcd_send_cmd(0x80|0x15);
		   								lcd_send_string("ATRAS");

		   								lcd_clear();
		   								if(HAL_GPIO_ReadPin(btn_encoder_GPIO_Port, btn_encoder_Pin)==0){
		   									HAL_Delay(5);
		   									while (HAL_GPIO_ReadPin(btn_encoder_GPIO_Port, btn_encoder_Pin)==0);
		   									HAL_Delay(5);
		   									menu = 11;
		   									pos = 0;
		   								}
		   								break;
		   							case 2://para cambiar la amplitud
		   								lcd_send_cmd(0x80|0x40);
		   								lcd_send_string(">");
		   								lcd_send_cmd(0x80|0x01);
		   								lcd_send_string("FRECUENCIA");
		   								lcd_send_cmd(0x80|0x41);
		   								lcd_send_string("AMPLITUD");
		   								lcd_send_cmd(0x80|0x15);
		   								lcd_send_string("ATRAS");
		   								lcd_clear();
		   								if(HAL_GPIO_ReadPin(btn_encoder_GPIO_Port, btn_encoder_Pin)==0){
		   									HAL_Delay(5);
		   									while (HAL_GPIO_ReadPin(btn_encoder_GPIO_Port, btn_encoder_Pin)==0);
		   									HAL_Delay(5);
		   									menu = 12;
		   									pos = 0;
		   								}
		   								break;
		   							case 3://para volver al menu principal
		   								lcd_send_cmd(0x80|0x14);
		   								lcd_send_string(">");
		   								lcd_send_cmd(0x80|0x01);
		   								lcd_send_string("FRECUENCIA");
		   								lcd_send_cmd(0x80|0x41);
		   								lcd_send_string("AMPLITUD");
		   								lcd_send_cmd(0x80|0x15);
		   								lcd_send_string("ATRAS");
		   								lcd_clear();
		   								if(HAL_GPIO_ReadPin(btn_encoder_GPIO_Port, btn_encoder_Pin)==0){
		   									HAL_Delay(5);
		   									while (HAL_GPIO_ReadPin(btn_encoder_GPIO_Port, btn_encoder_Pin)==0);
		   									HAL_Delay(5);
		   									menu = 0;
		   									pos = 0;
		   								}
		   								break;
		   							default:
		   								menu = 0;
		   								break;//fin switch 1.6
		   							}
		   							case 5: //frecuencia de senoidal
		   								lcd_clear();
		   								if (menu == 5) {
		   									fq1 = cont/5;
		   									lcd_enviar("FQ :", 1, 4);
		   									lcd_enviar_int(fq1, 1, 9);
		   								}
		   								if(HAL_GPIO_ReadPin(btn_encoder_GPIO_Port, btn_encoder_Pin)==0){
		   									HAL_Delay(5);
		   									while (HAL_GPIO_ReadPin(btn_encoder_GPIO_Port, btn_encoder_Pin)==0);
		   									HAL_Delay(5);
		   									lcd_clear();
		   									menu = 1;
		   									pos = 0;
		   								}
		   								break;
		   							case 6: //amplitud de senoidal
		   								lcd_clear();
		   								if (menu == 6) {
		   									amp1 = cont/5;
		   									lcd_enviar("AMP :", 1, 3);
		   									lcd_enviar_int(amp1, 1, 9);
		   								}
		   								if(HAL_GPIO_ReadPin(btn_encoder_GPIO_Port, btn_encoder_Pin)==0){
		   									HAL_Delay(5);
		   									while (HAL_GPIO_ReadPin(btn_encoder_GPIO_Port, btn_encoder_Pin)==0);
		   									HAL_Delay(5);
		   									lcd_clear();
		   									menu = 1;
		   									pos = 0;
		   								}
		   								break;
		   							case 7: //frecuencia triangular
		   								lcd_clear();
		   								if (menu == 7) {
		   									fq1 = cont/5;
		   									lcd_enviar("FQ :", 1, 4);
		   									lcd_enviar_int(fq1, 1, 9);
		   								}
		   								if(HAL_GPIO_ReadPin(btn_encoder_GPIO_Port, btn_encoder_Pin)==0){
		   									HAL_Delay(5);
		   									while (HAL_GPIO_ReadPin(btn_encoder_GPIO_Port, btn_encoder_Pin)==0);
		   									HAL_Delay(5);
		   									lcd_clear();
		   									menu = 2;
		   									pos = 0;
		   								}
		   								break;
		   							case 8: // amplitud triangular
		   								lcd_clear();
		   								if (menu == 8) {
		   									amp1 = cont/5;
		   									lcd_enviar("AMP :", 1, 3);
		   									lcd_enviar_int(amp1, 1, 9);
		   								}
		   								if(HAL_GPIO_ReadPin(btn_encoder_GPIO_Port, btn_encoder_Pin)==0){
		   									HAL_Delay(5);
		   									while (HAL_GPIO_ReadPin(btn_encoder_GPIO_Port, btn_encoder_Pin)==0);
		   									HAL_Delay(5);
		   									lcd_clear();
		   									menu = 2;
		   									pos = 0;
		   								}
		   								break;
		   							case 9: //frecuencia cuadrada
		   								lcd_clear();
		   								if (menu == 9) {
		   									fq1 = cont/5;
		   									lcd_enviar("FQ :", 1, 4);
		   									lcd_enviar_int(fq1, 1, 9);
		   								}
		   								if(HAL_GPIO_ReadPin(btn_encoder_GPIO_Port, btn_encoder_Pin)==0){
		   									HAL_Delay(5);
		   									while (HAL_GPIO_ReadPin(btn_encoder_GPIO_Port, btn_encoder_Pin)==0);
		   									HAL_Delay(5);
		   									lcd_clear();
		   									menu = 3;
		   									pos = 0;
		   								}
		   								break;
		   							case 10://amplitud cuadrada
		   								lcd_clear();
		   								if (menu == 10) {
		   									amp1 = cont/5;
		   									lcd_enviar("AMP :", 1, 3);
		   									lcd_enviar_int(amp1, 1, 9);
		   								}
		   								if(HAL_GPIO_ReadPin(btn_encoder_GPIO_Port, btn_encoder_Pin)==0){
		   									HAL_Delay(5);
		   									while (HAL_GPIO_ReadPin(btn_encoder_GPIO_Port, btn_encoder_Pin)==0);
		   									HAL_Delay(5);
		   									lcd_clear();
		   									menu = 3;
		   									pos = 0;
		   								}
		   								break;
		   							case 11://frecuencia cierra
		   								lcd_clear();
		   								if (menu == 11) {
		   									fq1 = cont/5;
		   									lcd_enviar("FQ :", 1, 4);
		   									lcd_enviar_int(fq1, 1, 9);
		   								}
		   								if(HAL_GPIO_ReadPin(btn_encoder_GPIO_Port, btn_encoder_Pin)==0){
		   									HAL_Delay(5);
		   									while (HAL_GPIO_ReadPin(btn_encoder_GPIO_Port, btn_encoder_Pin)==0);
		   									HAL_Delay(5);
		   									lcd_clear();
		   									menu = 4;
		   									pos = 0;
		   								}
		   								break;
		   							case 12://amplitud cierra
		   								lcd_clear();
		   								if (menu == 12) {
		   									amp1 = cont/5;
		   									lcd_enviar("AMP :", 1, 3);
		   									lcd_enviar_int(amp1, 1, 9);
		   								}
		   								if(HAL_GPIO_ReadPin(btn_encoder_GPIO_Port, btn_encoder_Pin)==0){
		   									HAL_Delay(5);
		   									while (HAL_GPIO_ReadPin(btn_encoder_GPIO_Port, btn_encoder_Pin)==0);
		   									HAL_Delay(5);
		   									lcd_clear();
		   									menu = 4;
		   									pos = 0;
		   								}
		   								break;
		   								break;//fin switch 1
		   		}
		   		if (fsen == 1) {
		   			//salida de funcion seno
		   			cuenta = 1;
		   		}
		   		else if (ftri == 1) {
		   			//saida de funcion triangular
		   			cuenta = 2;
		   		}
		   		else if (fcuad == 1) {
		   			//salida de funcion cuadrada
		   			cuenta = 3;
		   		}
		   		else if (fcier == 1) {
		   			//salida de funcion cierra
		   			cuenta = 4;
		   		}
		   		else {
		   			//ninguna salida
		   			cuenta = 0;
		   		}
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    /* USER CODE BEGIN 3 */
	}
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};
  RCC_PeriphCLKInitTypeDef PeriphClkInit = {0};

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI|RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_BYPASS;
  RCC_OscInitStruct.HSEPredivValue = RCC_HSE_PREDIV_DIV1;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLMUL = RCC_PLL_MUL9;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
  {
    Error_Handler();
  }
  PeriphClkInit.PeriphClockSelection = RCC_PERIPHCLK_I2C1|RCC_PERIPHCLK_TIM15;
  PeriphClkInit.I2c1ClockSelection = RCC_I2C1CLKSOURCE_HSI;
  PeriphClkInit.Tim15ClockSelection = RCC_TIM15CLK_HCLK;
  if (HAL_RCCEx_PeriphCLKConfig(&PeriphClkInit) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief DAC Initialization Function
  * @param None
  * @retval None
  */
static void MX_DAC_Init(void)
{

  /* USER CODE BEGIN DAC_Init 0 */

  /* USER CODE END DAC_Init 0 */

  DAC_ChannelConfTypeDef sConfig = {0};

  /* USER CODE BEGIN DAC_Init 1 */

  /* USER CODE END DAC_Init 1 */

  /** DAC Initialization
  */
  hdac.Instance = DAC;
  if (HAL_DAC_Init(&hdac) != HAL_OK)
  {
    Error_Handler();
  }

  /** DAC channel OUT1 config
  */
  sConfig.DAC_Trigger = DAC_TRIGGER_T15_TRGO;
  sConfig.DAC_OutputBuffer = DAC_OUTPUTBUFFER_ENABLE;
  if (HAL_DAC_ConfigChannel(&hdac, &sConfig, DAC_CHANNEL_1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN DAC_Init 2 */

  /* USER CODE END DAC_Init 2 */

}

/**
  * @brief I2C1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_I2C1_Init(void)
{

  /* USER CODE BEGIN I2C1_Init 0 */

  /* USER CODE END I2C1_Init 0 */

  /* USER CODE BEGIN I2C1_Init 1 */

  /* USER CODE END I2C1_Init 1 */
  hi2c1.Instance = I2C1;
  hi2c1.Init.Timing = 0x2000090E;
  hi2c1.Init.OwnAddress1 = 0;
  hi2c1.Init.AddressingMode = I2C_ADDRESSINGMODE_7BIT;
  hi2c1.Init.DualAddressMode = I2C_DUALADDRESS_DISABLE;
  hi2c1.Init.OwnAddress2 = 0;
  hi2c1.Init.OwnAddress2Masks = I2C_OA2_NOMASK;
  hi2c1.Init.GeneralCallMode = I2C_GENERALCALL_DISABLE;
  hi2c1.Init.NoStretchMode = I2C_NOSTRETCH_DISABLE;
  if (HAL_I2C_Init(&hi2c1) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure Analogue filter
  */
  if (HAL_I2CEx_ConfigAnalogFilter(&hi2c1, I2C_ANALOGFILTER_ENABLE) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure Digital filter
  */
  if (HAL_I2CEx_ConfigDigitalFilter(&hi2c1, 0) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN I2C1_Init 2 */

  /* USER CODE END I2C1_Init 2 */

}

/**
  * @brief TIM2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM2_Init(void)
{

  /* USER CODE BEGIN TIM2_Init 0 */

  /* USER CODE END TIM2_Init 0 */

  TIM_Encoder_InitTypeDef sConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};

  /* USER CODE BEGIN TIM2_Init 1 */

  /* USER CODE END TIM2_Init 1 */
  htim2.Instance = TIM2;
  htim2.Init.Prescaler = 0;
  htim2.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim2.Init.Period = 65535;
  htim2.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim2.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  sConfig.EncoderMode = TIM_ENCODERMODE_TI12;
  sConfig.IC1Polarity = TIM_ICPOLARITY_FALLING;
  sConfig.IC1Selection = TIM_ICSELECTION_DIRECTTI;
  sConfig.IC1Prescaler = TIM_ICPSC_DIV1;
  sConfig.IC1Filter = 0;
  sConfig.IC2Polarity = TIM_ICPOLARITY_FALLING;
  sConfig.IC2Selection = TIM_ICSELECTION_DIRECTTI;
  sConfig.IC2Prescaler = TIM_ICPSC_DIV1;
  sConfig.IC2Filter = 0;
  if (HAL_TIM_Encoder_Init(&htim2, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_UPDATE;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim2, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM2_Init 2 */

  /* USER CODE END TIM2_Init 2 */

}

/**
  * @brief TIM15 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM15_Init(void)
{

  /* USER CODE BEGIN TIM15_Init 0 */

  /* USER CODE END TIM15_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};

  /* USER CODE BEGIN TIM15_Init 1 */

  /* USER CODE END TIM15_Init 1 */
  htim15.Instance = TIM15;
  htim15.Init.Prescaler = 72-1;
  htim15.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim15.Init.Period = 100;
  htim15.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim15.Init.RepetitionCounter = 0;
  htim15.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim15) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim15, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_UPDATE;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim15, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM15_Init 2 */

  /* USER CODE END TIM15_Init 2 */

}

/**
  * @brief USART2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART2_UART_Init(void)
{

  /* USER CODE BEGIN USART2_Init 0 */

  /* USER CODE END USART2_Init 0 */

  /* USER CODE BEGIN USART2_Init 1 */

  /* USER CODE END USART2_Init 1 */
  huart2.Instance = USART2;
  huart2.Init.BaudRate = 38400;
  huart2.Init.WordLength = UART_WORDLENGTH_8B;
  huart2.Init.StopBits = UART_STOPBITS_1;
  huart2.Init.Parity = UART_PARITY_NONE;
  huart2.Init.Mode = UART_MODE_TX_RX;
  huart2.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart2.Init.OverSampling = UART_OVERSAMPLING_16;
  huart2.Init.OneBitSampling = UART_ONE_BIT_SAMPLE_DISABLE;
  huart2.AdvancedInit.AdvFeatureInit = UART_ADVFEATURE_NO_INIT;
  if (HAL_UART_Init(&huart2) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART2_Init 2 */

  /* USER CODE END USART2_Init 2 */

}

/**
  * Enable DMA controller clock
  */
static void MX_DMA_Init(void)
{

  /* DMA controller clock enable */
  __HAL_RCC_DMA1_CLK_ENABLE();

  /* DMA interrupt init */
  /* DMA1_Channel3_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(DMA1_Channel3_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(DMA1_Channel3_IRQn);

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};
/* USER CODE BEGIN MX_GPIO_Init_1 */
/* USER CODE END MX_GPIO_Init_1 */

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOF_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(LD2_GPIO_Port, LD2_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin : B1_Pin */
  GPIO_InitStruct.Pin = B1_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_FALLING;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(B1_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pin : LD2_Pin */
  GPIO_InitStruct.Pin = LD2_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(LD2_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pin : btn_encoder_Pin */
  GPIO_InitStruct.Pin = btn_encoder_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_PULLUP;
  HAL_GPIO_Init(btn_encoder_GPIO_Port, &GPIO_InitStruct);

/* USER CODE BEGIN MX_GPIO_Init_2 */
/* USER CODE END MX_GPIO_Init_2 */
}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
	/* User can add his own implementation to report the HAL error return state */
	__disable_irq();
	while (1)
	{
	}
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
	/* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
